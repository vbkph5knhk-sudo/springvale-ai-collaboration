#!/bin/bash
# 春谷镇项目 —— 一键启动脚本
# 用法：在终端里执行  bash setup.sh

set -e

echo "================================"
echo "  春谷镇项目初始化"
echo "================================"

# 1. 创建虚拟环境
echo ""
echo "[1/4] 创建虚拟环境 venv ..."
python3 -m venv venv
echo "  完成。"

# 2. 激活虚拟环境
echo ""
echo "[2/4] 激活虚拟环境 ..."
source venv/bin/activate
echo "  完成。命令行前面应该出现 (venv)。"

# 3. 安装依赖
echo ""
echo "[3/4] 安装依赖（Flask 等）..."
pip install -r requirements.txt
echo "  完成。"

# 4. 提示下一步
echo ""
echo "[4/4] 初始化完成！"
echo ""
echo "================================"
echo "  接下来启动网站："
echo "    source venv/bin/activate"
echo "    python app.py"
echo ""
echo "  然后浏览器打开 http://127.0.0.1:5000"
echo "================================"
