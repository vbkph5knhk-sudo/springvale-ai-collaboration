/*
 * 地图首页的前端交互层。
 * 它只负责“打开哪块抽屉、显示哪些内容”，不修改任务状态。
 * 真正的接取/开工/提交/验收仍然由 Flask 路由处理。
 */
const drawer = document.querySelector('#mapDrawer');
const drawerTitle = document.querySelector('#drawerTitle');
const drawerContent = document.querySelector('#drawerContent');
const drawerClose = document.querySelector('#drawerClose');

document.querySelectorAll('.map-flash').forEach((flash, index) => {
    window.setTimeout(() => {
        flash.classList.add('is-leaving');
        window.setTimeout(() => flash.remove(), 260);
    }, 3600 + index * 450);
});

const panelTitles = {
    welcome: '春谷广场',
    board: '任务领取点 · 等待领取',
    review: '验收大厅',
    ranking: '篝火排行榜',
    profile: '镇民档案',
    notifications: '通知中心',
    ai: '老镇长的小屋 · AI 助手',
    memorial: '重建纪念碑',
    shop: '春芽商店',
    hall: '镇务厅',
    checkin: '每日签到',
    news: '最新公告',
    season: '季节活动',
};

function openPanel(panelName) {
    const template = document.querySelector(`#panel-${panelName}`);
    if (!template) return;

    drawerTitle.textContent = panelTitles[panelName] || '春谷镇';
    drawerContent.replaceChildren(template.content.cloneNode(true));
    drawer.classList.add('open');

    document.querySelectorAll('.town-nav button').forEach((button) => {
        button.classList.toggle('active', button.dataset.panel === panelName);
    });

    wireDynamicPanel(panelName);
}

function closePanel() {
    drawer.classList.remove('open');
}

function wireDynamicPanel(panelName) {
    if (panelName === 'ai') {
        const chat = drawerContent.querySelector('.ai-chat');
        const input = drawerContent.querySelector('#aiInput');
        const messages = drawerContent.querySelector('#aiMessages');
        const send = drawerContent.querySelector('#aiSend');
        const quickButtons = [...drawerContent.querySelectorAll('.quick-prompts button')];
        const storageKey = `springvale-ai-chat-v1-${chat.dataset.userId}`;
        const storageLimit = 50;

        function readHistory() {
            try {
                const saved = JSON.parse(localStorage.getItem(storageKey) || '[]');
                if (!Array.isArray(saved)) return [];
                return saved.filter((item) =>
                    item && ['user', 'assistant'].includes(item.role) &&
                    typeof item.content === 'string' && item.content.trim()
                ).slice(-storageLimit);
            } catch (_) {
                return [];
            }
        }

        let history = readHistory();

        function saveHistory() {
            try {
                localStorage.setItem(storageKey, JSON.stringify(history.slice(-storageLimit)));
            } catch (_) {
                // 浏览器禁用本地存储时，当前对话仍可继续使用。
            }
        }

        function rememberMessage(role, content) {
            history.push({role, content});
            history = history.slice(-storageLimit);
            saveHistory();
        }

        function appendMessage(role, text, options = {}) {
            const turn = document.createElement('article');
            turn.className = `ai-turn ${role}${options.error ? ' error' : ''}${options.loading ? ' loading' : ''}`;
            if (options.id) turn.id = options.id;

            const avatar = document.createElement('img');
            avatar.className = 'ai-avatar';
            avatar.src = role === 'user' ? chat.dataset.userAvatar : chat.dataset.elderAvatar;
            avatar.alt = role === 'user' ? '我的头像' : '老镇长头像';

            const bubble = document.createElement('div');
            bubble.className = 'ai-bubble';
            const name = document.createElement('b');
            name.textContent = role === 'user' ? '我' : '老镇长';
            const content = document.createElement('p');
            content.textContent = text;
            bubble.append(name, content);
            turn.append(avatar, bubble);
            messages.append(turn);
            messages.scrollTop = messages.scrollHeight;
            return turn;
        }

        if (history.length) {
            messages.replaceChildren();
            history.forEach((item) => appendMessage(item.role, item.content));
        }

        function setSending(sending) {
            input.disabled = sending;
            send.disabled = sending;
            send.textContent = sending ? '思考中…' : '发送';
            quickButtons.forEach((button) => { button.disabled = sending; });
        }

        async function sendMessage(text) {
            const value = (text || input.value).trim();
            if (!value || send.disabled) return;

            const contextHistory = history.slice(-12);
            appendMessage('user', value);
            rememberMessage('user', value);
            input.value = '';
            setSending(true);

            const loadingId = 'loading-' + Date.now();
            appendMessage('assistant', '正在思考…', {loading: true, id: loadingId});

            try {
                const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
                const res = await fetch('/api/chat', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken},
                    body: JSON.stringify({message: value, history: contextHistory}),
                });
                const data = await res.json().catch(() => ({}));
                document.getElementById(loadingId)?.remove();

                if (res.ok && data.reply) {
                    appendMessage('assistant', data.reply);
                    rememberMessage('assistant', data.reply);
                } else {
                    appendMessage('assistant', data.error || '暂时无法回答，请稍后再试。', {error: true});
                }
            } catch (err) {
                document.getElementById(loadingId)?.remove();
                appendMessage('assistant', '网络暂时不稳定，请稍后再试。', {error: true});
            } finally {
                setSending(false);
                input.focus();
            }
        }

        send?.addEventListener('click', () => sendMessage());
        input?.addEventListener('keydown', (event) => {
            if (event.key === 'Enter') sendMessage();
        });
        quickButtons.forEach((button) => {
            button.addEventListener('click', () => sendMessage(button.textContent));
        });
    }
}

function escapeHtml(value) {
    const node = document.createElement('div');
    node.textContent = value;
    return node.innerHTML;
}

document.addEventListener('click', (event) => {
    const trigger = event.target.closest('[data-panel]');
    if (trigger) openPanel(trigger.dataset.panel);
});

drawerClose.addEventListener('click', closePanel);
document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') closePanel();
});

// 首次进入时不强制弹窗，让用户先看到完整小镇。
const initialPanel = new URLSearchParams(window.location.search).get('panel');
if (initialPanel && document.querySelector(`#panel-${initialPanel}`)) {
    openPanel(initialPanel);
}

// 升级通知第一次展示后写成已读；纪念碑里的预览不会修改任何数据。
const stageOverlay = document.querySelector('#stageUpgradeOverlay');
if (stageOverlay) {
    const town = document.querySelector('#town');
    const closeUpgrade = document.querySelector('#stageUpgradeClose');

    if (stageOverlay.dataset.seenUrl) {
        const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
        fetch(stageOverlay.dataset.seenUrl, {
            method: 'POST',
            headers: {'X-CSRF-Token': csrfToken},
        }).catch(() => {});
    }

    const dismissUpgrade = () => {
        stageOverlay.remove();
        town?.classList.add('stage-celebrating');
        window.setTimeout(() => town?.classList.remove('stage-celebrating'), 3000);
    };
    closeUpgrade?.addEventListener('click', dismissUpgrade);
    stageOverlay.addEventListener('click', (event) => {
        if (event.target === stageOverlay) dismissUpgrade();
    });
}
