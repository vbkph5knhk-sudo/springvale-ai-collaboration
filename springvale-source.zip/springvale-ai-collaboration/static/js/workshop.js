// “身份页签”切换我接取的任务 / 我发布的任务。
const tabButtons = document.querySelectorAll('[data-tab]');
const taskPanels = document.querySelectorAll('.task-panel[data-panel]');

function activatePanel(panelName) {
    tabButtons.forEach((item) => item.classList.toggle('active', item.dataset.tab === panelName));
    taskPanels.forEach((panel) => panel.classList.toggle('active', panel.dataset.panel === panelName));
}

tabButtons.forEach((button) => button.addEventListener('click', () => activatePanel(button.dataset.tab)));

// 发布者的验收提醒可以直接把用户带到“我发布的任务”。
document.querySelector('[data-open-published]')?.addEventListener('click', () => {
    activatePanel('published');
    const reviewButton = document.querySelector('[data-panel="published"] [data-filter="submitted"]');
    reviewButton?.click();
});

const groups = {
    all: () => true,
    unfinished: (state) => !['completed', 'closed'].includes(state),
    underway: (state) => ['accepted', 'processing', 'rejected'].includes(state),
    finished: (state) => ['completed', 'closed'].includes(state),
};

// 每个独立任务建筑页面只管理自己页面中的任务卡片。
const filters = document.querySelectorAll('[data-filter]');
const cards = document.querySelectorAll('[data-task-state]');
const filterEmpty = document.querySelector('.filter-empty');
filters.forEach((button) => {
    button.addEventListener('click', () => {
        const selected = button.dataset.filter;
        let visibleCount = 0;
        filters.forEach((item) => item.classList.toggle('active', item === button));
        cards.forEach((card) => {
            const state = card.dataset.taskState;
            const matches = groups[selected] ? groups[selected](state) : state === selected;
            card.hidden = !matches;
            if (matches) visibleCount += 1;
        });
        if (filterEmpty) filterEmpty.hidden = visibleCount !== 0;
    });
});

const flashes = document.querySelector('.workshop-flashes');
if (flashes) window.setTimeout(() => flashes.remove(), 3600);
